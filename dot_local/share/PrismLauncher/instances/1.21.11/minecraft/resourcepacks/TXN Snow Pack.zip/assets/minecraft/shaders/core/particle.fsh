#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;
in vec4 lightColor;
in vec4 rawColor;

out vec4 fragColor;

// ============================================================================
//  TXN SNOW PACK - TOTEM POP COLOUR
//  Edit TOTEM_COLOR (red, green, blue, each 0.0 - 1.0), save, press F3 + T.
//    ice blue     vec3(0.45, 0.80, 1.00)  (default)
//    crimson red  vec3(1.00, 0.04, 0.10)
//    blood red    vec3(0.70, 0.00, 0.05)
//    silver       vec3(0.85, 0.88, 0.95)
//    purple       vec3(0.60, 0.25, 1.00)
//    gold         vec3(1.00, 0.75, 0.10)
//  TOTEM_WHITE_CORE: how white-hot the centre of each glint gets (0.0 - 1.0)
// ============================================================================
#define TOTEM_COLOR vec3(0.45, 0.80, 1.00)
#define TOTEM_WHITE_CORE 0.75

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    vec4 color;
    // Totem pop glints are drawn with alpha 254: ignore the game's random
    // green/yellow tint, paint them in TOTEM_COLOR and make them fullbright.
    if (abs(tex.a * 255.0 - 254.0) < 0.5) {
        float l = dot(tex.rgb, vec3(0.2126, 0.7152, 0.0722));
        vec3 c = TOTEM_COLOR * (l * 1.25);
        c = mix(c, vec3(1.0), smoothstep(0.92, 1.0, l) * TOTEM_WHITE_CORE);
        color = vec4(c, rawColor.a) * ColorModulator;
    } else {
        color = tex * vertexColor * ColorModulator;
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
